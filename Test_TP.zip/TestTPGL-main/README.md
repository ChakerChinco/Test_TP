# TestTPGL  
Test TP Labyrinth application
Realised by 
OUABID Islam 
DOUMAZ Issam

in the Class Maze in The labyrinth to add the orientation images please change the absolute 
path .

