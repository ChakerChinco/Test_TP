package org.emp.gl.gui1;

import org.emp.gl.labyrinthservice.ServiceMaze;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.SwingUtilities;
import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.rebotservice.Position;
import org.emp.gl.rebotservice.RebotService;
import org.emp.gl.timer.TimerObserver;

/**
 *
 * @author MacOs
 */
public class Maze extends JFrame implements ServiceMaze {

    private int[][] labyrinth
            = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1},
            {1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1},
            {1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1},
            {1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 9, 1},
            {1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}

            };

    public Maze() {

        setTitle("Maze Runner");
        setSize(500, 480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    @Override
    public void paint(Graphics g) {

        super.paint(g);

        for (int row = 0; row < labyrinth.length; row++) {
            for (int col = 0; col < labyrinth[0].length; col++) {

                Color color;
                switch (labyrinth[row][col]) {
                    case 1:color = Color.YELLOW; break;
                    case 9:color = Color.GREEN; break;
                       
                    default:
                        color = Color.CYAN;
                }
                g.setColor(color);
                g.fillRect(30 * col, 30 * row, 30, 30);
                g.setColor(Color.BLACK);
                g.drawRect(30 * col, 30 * row, 30, 30);

            }
        }
        RebotService r = Lookup.getLookup().get(RebotService.class);
        int pathX = r.getPosition().x;
        int pathY = r.getPosition().y;

        
            g.setColor(Color.RED);
            g.fillOval(pathX * 30, pathY * 30, 28, 28);
           
       

    }

    @Override
    protected void processKeyEvent(KeyEvent ke) {

        if (ke.getID() != KeyEvent.KEY_PRESSED) {
            return;
        }
        if (ke.getKeyCode() == KeyEvent.VK_RIGHT) {
            Lookup.getLookup().get(RebotService.class).buttonRightPressed();
        } else if (ke.getKeyCode() == KeyEvent.VK_LEFT) {
            Lookup.getLookup().get(RebotService.class).buttonLeftPressed();
        } else if (ke.getKeyCode() == KeyEvent.VK_DOWN) {
            Lookup.getLookup().get(RebotService.class).buttonDownPressed();
        } else if (ke.getKeyCode() == KeyEvent.VK_UP) {
            Lookup.getLookup().get(RebotService.class).buttonUpPressed();
        }
        repaint();
    }

    @Override
    public void move() {
        repaint();
    }

    @Override
    public boolean isObstacle(int i, int j) {
        if (labyrinth[j][i] == 0) {
            return false;
        } else {
            return true;
        }
    }

}
