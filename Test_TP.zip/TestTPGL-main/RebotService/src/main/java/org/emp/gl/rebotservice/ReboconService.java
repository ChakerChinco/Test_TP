/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.rebotservice;

import org.emp.gl.timer.TimerObserver;
import org.emp.gl.timer.TimerService;

/**
 *
 * @author MacOs
 */
public interface ReboconService extends TimerObserver {

    public final static String UP_Orientation = "UP";
    public final static String DOWN_Orientation = "Down";
    public final static String LEFT_Orientation = "Left";
    public final static String RIGHT_Orientation = "Right";

    public Position getPosition();

    public String getOrientation();

    public void buttonUpClicked();

    public void buttonDownClicked();

    public void buttonLeftClicked();

    public void buttonRightClicked();
}
